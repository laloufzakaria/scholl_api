

<form class="form" method="post" action="<?php echo e(route('apilogin')); ?>">
            <?php echo csrf_field(); ?>

            <div class="card card-login card-white">
                <div class="card-header">
                    <img src="<?php echo e(asset('black')); ?>/img/card-primary.png" alt="">
                    <h1 class="card-title"><?php echo e(__('')); ?></h1>
                </div>
                <div class="card-body">
                    <p class="text-dark mb-2">Sign in </p>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <i class="tim-icons icon-email-85"></i>
                            </div>
                        </div>
                        <input type="email" name="email" class="form-control" placeholder="<?php echo e(__('Email')); ?>">
                    </div>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <i class="tim-icons icon-lock-circle"></i>
                            </div>
                        </div>
                        <input type="password" placeholder="<?php echo e(__('Password')); ?>" name="password" class="form-control">
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" href="" class="btn btn-primary btn-lg btn-block mb-3"><?php echo e(__('Get Started')); ?></button>
                    <div class="pull-right">
                        <h6>
                            <a href="<?php echo e(route('password.request')); ?>" class="link footer-link"><?php echo e(__('Forgot password?')); ?></a>
                        </h6>
                    </div>
                </div>
            </div>
        </form>

<?php /**PATH G:\Project\PHP Project\Laravel\school\resources\views/pages/test.blade.php ENDPATH**/ ?>