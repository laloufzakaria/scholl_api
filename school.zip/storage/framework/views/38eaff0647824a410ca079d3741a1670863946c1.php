<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="card">
        <div class="card-header">
            <h5 class="title"><?php echo e(__('Personne')); ?></h5>
        </div>
        <form method="post" action="<?php echo e(route('personne.store')); ?>" autocomplete="off">
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('First Name')); ?></label>
                    <input type="text" name="firstname" id="firstname" class="form-control<?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('First Name')); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'firstname'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="form-group<?php echo e($errors->has('lastname') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('Last Name')); ?></label>
                    <input type="text" name="lastname" id="lastname" class="form-control<?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Last Name')); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'lastname'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="form-group<?php echo e($errors->has('mobileno') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('Mobile no')); ?></label>
                    <input type="phone" name="mobileno" id="mobileno" class="form-control<?php echo e($errors->has('mobileno') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('06...')); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'mobileno'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('Email')); ?></label>
                    <input type="email" name="email" id="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('Password')); ?></label>
                    <input type="password" name="password" id="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="form-group<?php echo e($errors->has('dob') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('Date de naissance')); ?></label>
                    <input type="date" name="dob" id="dob" class="form-control<?php echo e($errors->has('dob') ? ' is-invalid' : ''); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'dob'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="form-group<?php echo e($errors->has('gender') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('Gender')); ?></label>
                    <input type="text" name="gender" id="gender" class="form-control<?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('m or f')); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'gender'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="form-group<?php echo e($errors->has('class_id') ? ' has-danger' : ''); ?>">
                <select class="form-control" name="category_id" style="width: 35%;">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="text-dark" value=<?php echo e($categorie->id); ?>><?php echo e($categorie->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'category_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </select>
                </div>
                <div class="form-group<?php echo e($errors->has('class_id') ? ' has-danger' : ''); ?>">
                <select class="form-control" name="class_id" style="width: 35%;" >
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="text-dark" value=<?php echo e($classe->id); ?>><?php echo e($classe->class); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'class_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </select>
                </div>
                <div class="form-group<?php echo e($errors->has('is_active') ? ' has-danger' : ''); ?>">
                    <label><?php echo e(__('is Active')); ?></label>
                    <input type="text" name="is_active" id="is_active" class="form-control<?php echo e($errors->has('is_active') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('yes or no')); ?>" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'is_active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-fill btn-primary"><?php echo e(__('Save')); ?></button>
            </div>
        </form>
    </div>
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header">
                <h4 class="card-title"> Personnes</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="personne_table" class="table tablesorter">
                        <thead class="text-primary">
                            <tr>
                                <th> Id</th>
                                <th> First Name</th>
                                <th> Last Name</th>
                                <th> Email</th>
                                <th> Is Active</th>
                                <th> Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item<?php echo e($item->id); ?>">
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->firstname); ?></td>
                                <td><?php echo e($item->lastname); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->is_active); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow" x-placement="bottom-end" style="position: absolute; transform: translate3d(-108px, 28px, 0px); top: 0px; left: 0px; will-change: transform;">
                                            <button class="edit-modal dropdown-item" data-info="<?php echo e($item->id); ?>,<?php echo e($item->firstname); ?>,<?php echo e($item->lastname); ?>,<?php echo e($item->email); ?>,<?php echo e($item->is_active); ?>">Edit</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body">

                    <form class="form-horizontal" role="form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>


                        <div class="form-group">
                            <label class="control-label col-sm-2" for="mid">ID</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control text-muted" id="mid" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="mname">First Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control  text-dark" id="mname" name="mname">
                                <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="mcode">Lats Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control  text-dark" id="mcode" name="mcode">
                                <?php echo $__env->make('alerts.feedback', ['field' => 'code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="mtype">Email</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control  text-dark" id="mtype" name="mtype">
                                <?php echo $__env->make('alerts.feedback', ['field' => 'type'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="macive">Active:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control text-dark" id="mactive" name="mactive">
                                <?php echo $__env->make('alerts.feedback', ['field' => 'is_active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn actionBtn" data-dismiss="modal">
                                <span id="footer_action_button" class='glyphicon'> </span>
                            </button>
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <span class='glyphicon glyphicon-remove'></span> Close
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('black')); ?>/js/core/jquery.min.js"></script>
<script>
    function fillmodalData(details) {
        $('#mid').val(details[0]);
        $('#mname').val(details[1]);
        $('#mcode').val(details[2]);
        $('#mtype').val(details[3]);
        $('#mactive').val(details[4]);
    }
    $(document).on('click', '.edit-modal', function() {
        $('#footer_action_button').text(" Update");
        $('.actionBtn').addClass('btn-success');
        $('.actionBtn').removeClass('btn-danger');
        $('.actionBtn').removeClass('delete');
        $('.actionBtn').addClass('edit');
        $('.modal-title').text('Edit');
        $('.deleteContent').hide();
        $('.form-horizontal').show();
        var stuff = $(this).data('info').split(',');
        fillmodalData(stuff)
        $('#myModal').modal('show');
    });


    $('.modal-footer').on('click', '.edit', function() {
        $.ajax({
            type: 'post',
            url: 'personne/update',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                '_token': $('input[name=_token]').val(),
                'firstname': $('#mname').val(),
                'lastname': $('#mcode').val(),
                'email': $('#mtype').val(),
                'is_active': $('#mactive').val(),
                'id': $('#mid').val()

            },
            success: function(data) {
                location.reload();
            }
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['page' => __('Personnes'), 'pageSlug' => 'personne'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\PHP Project\Laravel\school\resources\views/pages/personne.blade.php ENDPATH**/ ?>