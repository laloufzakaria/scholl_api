<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="#" class="simple-text logo-mini"><?php echo e(__('SD')); ?></a>
            <a href="#" class="simple-text logo-normal"><?php echo e(__('School Dashboard')); ?></a>
        </div>
        <ul class="nav">
            <li <?php if($pageSlug == 'dashboard'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li>
                <a data-toggle="collapse" href="#laravel-examples" aria-expanded="true">
                    <i class="tim-icons icon-single-02" ></i>
                    <span class="nav-link-text" ><?php echo e(__('Student')); ?></span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse show" id="laravel-examples">
                    <ul class="nav pl-4">
                        <li <?php if($pageSlug == 'profile'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('profile.edit')); ?>">
                                <i class="tim-icons icon-pencil"></i>
                                <p><?php echo e(__('User Profile')); ?></p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'personne'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('pages.personne')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <p><?php echo e(__('Student Management')); ?></p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'category'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('pages.category')); ?>">
                                <i class="tim-icons icon-badge"></i>
                                <p><?php echo e(__('Categorie')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li <?php if($pageSlug == 'classe'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('pages.classe')); ?>">
                    <i class="tim-icons icon-bell-55"></i>
                    <p><?php echo e(__('Classes')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'session'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('pages.session')); ?>">
                    <i class="tim-icons icon-puzzle-10"></i>
                    <p><?php echo e(__('Sessions')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'subject'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('pages.subject')); ?>">
                    <i class="tim-icons icon-puzzle-10"></i>
                    <p><?php echo e(__('Subjects')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'teacher_subject'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('pages.teacher_subject')); ?>">
                    <i class="tim-icons icon-puzzle-10"></i>
                    <p><?php echo e(__('Teacher subject')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'timetable'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('pages.timetable')); ?>">
                    <i class="tim-icons icon-align-center"></i>
                    <p><?php echo e(__('Gestion Emplois')); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH G:\Project\PHP Project\Laravel\school\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>