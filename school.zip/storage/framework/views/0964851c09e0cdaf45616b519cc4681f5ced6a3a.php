<footer class="footer">
    <div class="container-fluid">
        <ul class="nav">
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <?php echo e(__('About Us')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <?php echo e(__('Blog')); ?>

                </a>
            </li>
        </ul>
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('made with')); ?> <i class="tim-icons icon-heart-2"></i> <?php echo e(__('by Lalouf')); ?>

        </div>
    </div>
</footer>
<?php /**PATH G:\Project\PHP Project\Laravel\school\resources\views/layouts/footer.blade.php ENDPATH**/ ?>