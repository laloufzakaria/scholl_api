<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="card">
    <div class="card-header">
      <h5 class="title"><?php echo e(__('Categorie')); ?></h5>
    </div>
    <form method="post" action="<?php echo e(route('category.store')); ?>" autocomplete="off">
      <div class="card-body">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
          <label><?php echo e(__('Name')); ?></label>
          <input type="text" name="name" id="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="">
          <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="form-group<?php echo e($errors->has('is_active') ? ' has-danger' : ''); ?>">
          <label><?php echo e(__('is Alive')); ?></label>
          <input type="text" name="is_active" id="is_active" class="form-control<?php echo e($errors->has('is_active') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('yes & no')); ?>" value="">
          <?php echo $__env->make('alerts.feedback', ['field' => 'is_active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
      <div class="card-footer">
        <button type="submit" class="btn btn-fill btn-primary"><?php echo e(__('Save')); ?></button>
      </div>
    </form>
  </div>
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h4 class="card-title"> Categories</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="category_table" class="table tablesorter">
            <thead class="text-primary">
              <tr>
                <th>Id</th>
                <th> Name</th>
                <th>Is Active</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="item<?php echo e($item->id); ?>">
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->is_active); ?></td>
                <td>
                  <div class="dropdown">
                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow" x-placement="bottom-end" style="position: absolute; transform: translate3d(-108px, 28px, 0px); top: 0px; left: 0px; will-change: transform;">
                      <button class="edit-modal dropdown-item" data-info="<?php echo e($item->id); ?>,<?php echo e($item->name); ?>,<?php echo e($item->is_active); ?>">Edit</a>
                    </div>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body">

          <form class="form-horizontal" role="form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
              <label class="control-label col-sm-2" for="mid">ID</label>
              <div class="col-sm-10">
                <input type="text" class="form-control text-muted" id="mid" disabled>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="mname">Name</label>
              <div class="col-sm-10">
                <input type="text" class="form-control  text-dark" id="mname" name="mname">
                <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="macive">Active:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control text-dark" id="mactive" name="mactive">
                <?php echo $__env->make('alerts.feedback', ['field' => 'is_active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn actionBtn" data-dismiss="modal">
                <span id="footer_action_button" class='glyphicon'> </span>
              </button>
              <button type="button" class="btn btn-warning" data-dismiss="modal" >
                <span class='glyphicon glyphicon-remove'></span> Close
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="<?php echo e(asset('black')); ?>/js/core/jquery.min.js"></script>
<script>
  function fillmodalData(details) {
    $('#mid').val(details[0]);
    $('#mname').val(details[1]);
    $('#mactive').val(details[2]);
  }
  $(document).on('click', '.edit-modal', function() {
    $('#footer_action_button').text(" Update");
    $('.actionBtn').addClass('btn-success');
    $('.actionBtn').removeClass('btn-danger');
    $('.actionBtn').removeClass('delete');
    $('.actionBtn').addClass('edit');
    $('.modal-title').text('Edit');
    $('.deleteContent').hide();
    $('.form-horizontal').show();
    var stuff = $(this).data('info').split(',');
    fillmodalData(stuff)
    $('#myModal').modal('show');
  });


  $('.modal-footer').on('click', '.edit', function() {
    $.ajax({
      type: 'post',
      url: 'category/update',
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      data: {
        '_token': $('input[name=_token]').val(),
        'name': $('#mname').val(),
        'is_active': $('#mactive').val(),
        'id': $('#mid').val()

      },
      success: function(data) {
        location.reload();
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['page' => __('Categorie'), 'pageSlug' => 'category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\PHP Project\Laravel\school\resources\views/pages/category.blade.php ENDPATH**/ ?>