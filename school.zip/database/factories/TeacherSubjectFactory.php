<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Teacher_subject;
use Faker\Generator as Faker;

$factory->define(Teacher_subject::class, function (Faker $faker) {
    return [
        //
    ];
});
